<?php 
include 'koneksi.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $txtusername = mysqli_real_escape_string($konek, $_POST['txtusername']);
    $txtpassword = md5($_POST['txtpassword']);

    $cek = mysqli_query($konek, "SELECT * FROM tbl_user WHERE user_name='$txtusername' AND password='$txtpassword'");
    $hasil = mysqli_fetch_array($cek);
    $count = mysqli_num_rows($cek);

    if ($count > 0) {
        $_SESSION['user_name'] = $hasil['user_name'];
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Username atau Password salah!"]);
    }
    exit();
}
