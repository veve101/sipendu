<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Penduduk</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <style>
    .footer {
        background-color: #f8f9fa;
        padding: 15px 10px;
        text-align: center;
        font-size: 14px;
        color: #6c757d;
    }

    @media (max-width: 576px) {
        .footer {
            font-size: 12px;
            padding: 10px 5px;
        }
    }


    </style>
</head>
<body>
    <header>
        <!-- Header atau Navigasi -->
    </header>
    
    <div class="container-fluid">
        <!-- Konten utama -->
    </div>
    
    <footer class="footer">
            Copyright © 2024 PEMDES TRAYEMAN. All rights reserved.
        </footer>

    <script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
