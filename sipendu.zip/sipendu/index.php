<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Kependudukan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #003366, #3399ff);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.1);
            padding: 50px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: white;
            width: 500px;
            transition: transform 0.3s ease-in-out;
        }
        .login-container:hover {
            transform: scale(1.05);
        }
        .login-container img {
            max-height: 70px;
            margin: 10px;
        }
        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .btn-primary {
            background: #ff9900;
            border: none;
            font-weight: bold;
            transition: background 0.3s ease-in-out;
        }
        .btn-primary:hover {
            background: #cc7700;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <div class="mb-3">
            <img src="tegal.png" alt="Logo Tegal">
            <img src="utd.png" alt="Logo UTD">
        </div>
        <h3 class="mb-4">USER LOGIN</h3>
        <form id="login-form">
            <div class="mb-3">
                <input type="text" class="form-control" name="txtusername" placeholder="Username" required>
            </div>
            <div class="mb-3">
                <input type="password" class="form-control" name="txtpassword" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">LOGIN</button>
        </form>
    </div>

    <!-- Modal untuk Peringatan Login Gagal -->
    <div class="modal fade" id="errorModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Login Gagal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p id="errorMessage"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Coba Lagi</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        $("#login-form").submit(function(event) {
            event.preventDefault();
            $.ajax({
                type: "POST",
                url: "login.php", 
                data: $(this).serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        window.location.href = "beranda.php"; 
                    } else {
                        $("#errorMessage").text(response.message);
                        $("#errorModal").modal("show");
                    }
                }
            });
        });
    </script>

</body>
</html>
