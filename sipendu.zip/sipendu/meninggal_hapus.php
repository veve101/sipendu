<?php
include 'koneksi.php'; 
if (isset($_GET[penduduk_id])){
	$qry=mysqli_query($konek,"delete from tbl_kematian where kode='".$_GET["penduduk_id"]."'");
	if ($qry){
		header('location: meninggal_tampil.php');
	}
}
?>