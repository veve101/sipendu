<?php
include 'header.php';
?>

<section class="content">
  <div class="row">
    <?php
    // Menggunakan fungsi COUNT untuk menghitung jumlah data berdasarkan jenis penduduk
    $query = mysqli_query($konek, "
      SELECT 
        SUM(CASE WHEN jenis = 'Pindah' THEN 1 ELSE 0 END) AS pindah,
        SUM(CASE WHEN jenis = 'Meninggal' THEN 1 ELSE 0 END) AS meninggal,
        SUM(CASE WHEN jenis = 'Pendatang' THEN 1 ELSE 0 END) AS pendatang,
        SUM(CASE WHEN jenis = 'Lahir' THEN 1 ELSE 0 END) AS lahir,
        SUM(CASE WHEN jenis = 'Tetap' THEN 1 ELSE 0 END) AS tetap,
        COUNT(*) AS total
      FROM tbl_warga
    ");
    $data = mysqli_fetch_assoc($query);

    // Menyimpan hasil dalam variabel
    $pindah = $data['pindah'];
    $meninggal = $data['meninggal'];
    $pendatang = $data['pendatang'];
    $lahir = $data['lahir'];
    $tetap = $data['tetap'];
    $total = $data['total'];
    ?>

    <!-- Kotak Penduduk Pindah -->
    <div class="col-lg-6 col-xs-6">
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3><?php echo $pindah; ?></h3>
          <p>Penduduk Pindah</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
      </div>
    </div>

    <!-- Kotak Penduduk Meninggal -->
    <div class="col-lg-6 col-xs-6">
      <div class="small-box bg-green">
        <div class="inner">
          <h3><?php echo $meninggal; ?></h3>
          <p>Penduduk Meninggal</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
      </div>
    </div>

    <!-- Kotak Penduduk Pendatang -->
    <div class="col-lg-6 col-xs-6">
      <div class="small-box bg-yellow">
        <div class="inner">
          <h3><?php echo $pendatang; ?></h3>
          <p>Penduduk Pendatang</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
      </div>
    </div>

    <!-- Kotak Penduduk Lahir -->
    <div class="col-lg-6 col-xs-6">
      <div class="small-box bg-red">
        <div class="inner">
          <h3><?php echo $lahir; ?></h3>
          <p>Penduduk Lahir</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <!-- Kotak Penduduk Tetap -->
    <div class="col-lg-6 col-xs-6">
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3><?php echo $tetap; ?></h3>
          <p>Penduduk Tetap</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
      </div>
    </div>

    <!-- Kotak Total Penduduk -->
    <div class="col-lg-6 col-xs-6">
      <div class="small-box bg-green">
        <div class="inner">
          <h3><?php echo $total; ?></h3>
          <p>Total Penduduk</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
      </div>
    </div>
  </div>

  <!-- Grafik Data Warga -->
  <div class="row">
    <div class="col-lg-12 col-xs-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Grafik Data Warga</h3>
        </div>
        <div class="box-body">
          <canvas id="grafikDataWarga" width="400" height="200"></canvas>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Tambahkan Library Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  // Ambil data dari PHP
  const dataWarga = {
    labels: ['Pindah', 'Meninggal', 'Pendatang', 'Lahir', 'Tetap'],
    datasets: [{
      label: 'Jumlah Penduduk',
      data: [
        <?php echo $pindah; ?>,
        <?php echo $meninggal; ?>,
        <?php echo $pendatang; ?>,
        <?php echo $lahir; ?>,
        <?php echo $tetap; ?>
      ],
      backgroundColor: [
        'rgba(54, 162, 235, 0.6)', // Biru
        'rgba(75, 192, 192, 0.6)', // Hijau
        'rgba(255, 206, 86, 0.6)', // Kuning
        'rgba(255, 99, 132, 0.6)', // Merah
        'rgba(153, 102, 255, 0.6)' // Ungu
      ],
      borderColor: [
        'rgba(54, 162, 235, 1)', 
        'rgba(75, 192, 192, 1)', 
        'rgba(255, 206, 86, 1)', 
        'rgba(255, 99, 132, 1)', 
        'rgba(153, 102, 255, 1)'
      ],
      borderWidth: 1
    }]
  };

  const config = {
    type: 'bar', // Jenis grafik: bar
    data: dataWarga,
    options: {
      responsive: true,
      plugins: {
        legend: {
          display: true,
          position: 'top',
        }
      },
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  };

  // Render grafik
  const ctx = document.getElementById('grafikDataWarga').getContext('2d');
  new Chart(ctx, config);
</script>
<?php include'footer.php'; ?> 