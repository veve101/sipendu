<?php include 'header.php'; ?>
<br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-info">
                <div class="box-header with-border">
                    <form action="" method="POST">
                        <div class="row">
                            <div class="col-sm-10 mb-2">
                                <input type="text" class="form-control" id="uraian" name="query" placeholder="Cari NIK & Nama" required oninvalid="this.setCustomValidity('Input Pencarian Anda NIK atau Nama Penduduk')" oninput="setCustomValidity('')" />
                            </div>
                            <div class="col-sm-2">
                                <button type="submit" name="cari" class="btn btn-primary btn-block">Cari</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">
                        | Data Penduduk
                            <a href="penduduk_add.php" class="btn btn-success btn-sm">Tambah</a>
                            
                            <a href="#" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modalCetak">Cetak</a>
                        </h3>
                    </div>
                    <div class="box-body no-padding">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th width="5%">NO</th>
                                        <th>NIK</th>
                                        <th>NAMA</th>
                                        <th>TGL LAHIR</th>
                                        <th>JENIS KELAMIN</th>
                                        <th>JENIS PENDUDUK</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $query = $_POST['query'] ?? '';
                                    if ($query != '') {
                                        $select = mysqli_query($konek, "SELECT * FROM tbl_warga WHERE nik LIKE '%$query%' OR nama LIKE '%$query%' OR jenis LIKE '%$query%'");
                                    } else {
                                        $select = mysqli_query($konek, "SELECT * FROM tbl_warga");
                                    }
                                    if (mysqli_num_rows($select)) {
                                        while ($data = mysqli_fetch_array($select)) {
                                    ?>
                                            <tr>
                                                <td> <?php echo $no++; ?> </td>
                                                <td> <?php echo $data['nik']; ?> </td>
                                                <td> <?php echo $data['nama']; ?> </td>
                                                <td> <?php echo $data['tgl_lahir']; ?> </td>
                                                <td> <?php echo $data['jenis_kelamin']; ?> </td>
                                                <td>
                                                    <select class="form-control jenis-penduduk" data-id="<?php echo $data['kode']; ?>">
                                                        <option value="Tetap" <?php if ($data['jenis'] == 'Tetap') echo 'selected'; ?>>Tetap</option>
                                                        <option value="Pendatang" <?php if ($data['jenis'] == 'Pendatang') echo 'selected'; ?>>Pendatang</option>
                                                        <option value="Meninggal" <?php if ($data['jenis'] == 'Meninggal') echo 'selected'; ?>>Meninggal</option>
                                                        <option value="Pindah" <?php if ($data['jenis'] == 'Pindah') echo 'selected'; ?>>Pindah</option>
                                                        <option value="Lahir" <?php if ($data['jenis'] == 'Lahir') echo 'selected'; ?>>Lahir</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <a href="penduduk_edit.php?penduduk_id=<?php echo base64_encode($data['kode']); ?>" class="btn btn-warning btn-sm">Edit</a>
                                                    <a onClick="return confirm('Yakin Anda Menghapus ?')" href="penduduk_hapus.php?penduduk_id=<?php echo $data['kode']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                                                    <a href="profil.php?penduduk_id=<?php echo base64_encode($data['kode']); ?>" class="btn btn-primary btn-sm">Detail</a>
                                                </td>
                                            </tr>
                                    <?php }
                                    } else {
                                        echo "<tr><td colspan='7' class='text-center'>Data tidak ditemukan</td></tr>";
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal Cetak -->
<div class="modal fade" id="modalCetak" tabindex="-1" role="dialog" aria-labelledby="modalCetakLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="cetak.php" method="GET" target="_blank">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalCetakLabel">Filter Cetak Data Penduduk</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="bulan">Pilih Bulan</label>
                        <input type="month" class="form-control" id="bulan" name="bulan">
                    </div>
                    <div class="form-group">
                        <label for="jenisPenduduk">Status Penduduk</label>
                        <select class="form-control" id="jenisPenduduk" name="jenis">
                            <option value="">Semua</option>
                            <option value="Tetap">Tetap</option>
                            <option value="Pendatang">Pendatang</option>
                            <option value="Meninggal">Meninggal</option>
                            <option value="Pindah">Pindah</option>
                            <option value="Lahir">Lahir</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" class="form-control" id="nik" name="nik" placeholder="Cari berdasarkan NIK">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Cetak</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $(".jenis-penduduk").change(function() {
            var id = $(this).data("id");
            var jenis = $(this).val();
            $.ajax({
                url: "update_jenis.php",
                type: "POST",
                data: { id: id, jenis: jenis },
                success: function(response) {
                    alert(response);
                },
                error: function() {
                    alert("Gagal memperbarui data.");
                }
            });
        });
    });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $(".jenis-penduduk").change(function() {
            var id = $(this).data("id");
            var jenis = $(this).val();
            $.ajax({
                url: "update_jenis.php",
                type: "POST",
                data: { id: id, jenis: jenis },
                success: function(response) {
                    alert(response);
                },
                error: function() {
                    alert("Gagal memperbarui data.");
                }
            });
        });
    });
</script>
