<?php
include 'koneksi.php';

// Ambil filter jika ada
$bulan = $_GET['bulan'] ?? '';
$jenis = $_GET['jenis'] ?? '';
$nik = $_GET['nik'] ?? '';

// Query ambil data
$query = "SELECT * FROM tbl_warga WHERE 1=1";
if ($bulan) {
    $query .= " AND DATE_FORMAT(tgl_lahir, '%Y-%m') = '" . mysqli_real_escape_string($konek, $bulan) . "'";
}
if ($jenis) {
    $query .= " AND jenis = '" . mysqli_real_escape_string($konek, $jenis) . "'";
}
if ($nik) {
    $query .= " AND nik = '" . mysqli_real_escape_string($konek, $nik) . "'";
}

$result = mysqli_query($konek, $query);
$jumlahData = mysqli_num_rows($result);

// Fungsi untuk format tanggal Indonesia
function formatTanggal($tanggal) {
    return date('d F Y', strtotime($tanggal));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Kependudukan</title>
    <style>
        @page {
            size: A4 portrait;
            margin: 1.5cm;
        }
        body {
            font-family: "Times New Roman", Times, serif;
            font-size: 12pt;
            margin: 0;
            padding: 0;
        }
        .header {
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 3px solid black;
        }
        .header img {
            width: 90px;
            height: auto;
            margin-right: 10px;
        }
        .header .kop {
            text-align: center;
            flex: 1;
        }
        .header .kop h2 {
            margin: 0;
            font-size: 18pt;
        }
        .header .kop p {
            margin: 3px 0;
            font-size: 12pt;
        }
        .info {
            margin-top: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid black;
            padding: 6px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .signature {
            width: 100%;
            text-align: right;
            margin-top: 50px;
        }
        .signature p {
            margin-bottom: 50px;
        }
    </style>
</head>
<body onload="window.print()">
    <div class="header">
        <img src="tegal.png" alt="Logo Kabupaten Tegal">
        <div class="kop">
            <h2>PEMERINTAH KABUPATEN TEGAL</h2>
            <p>KECAMATAN SLAWI, DESA TRAYEMAN</p>
            <p>Alamat: Jl. Raya Trayeman, Slawi, Kabupaten Tegal</p>
        </div>
    </div>

    <h3 style="text-align: center; text-decoration: underline;">LAPORAN DATA KEPENDUDUKAN</h3>

    <div class="info">
        <strong>Tanggal Cetak:</strong> <?php echo formatTanggal(date('Y-m-d')); ?><br>
        <strong>Jumlah Data:</strong> <?php echo $jumlahData; ?>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>NIK</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Status Penduduk</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($jumlahData > 0) {
                $no = 1;
                while ($data = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>" . $no++ . "</td>
                            <td>" . htmlspecialchars($data['nik']) . "</td>
                            <td>" . htmlspecialchars($data['nama']) . "</td>
                            <td>" . formatTanggal($data['tgl_lahir']) . "</td>
                            <td>" . htmlspecialchars($data['jenis_kelamin']) . "</td>
                            <td>" . htmlspecialchars($data['jenis']) . "</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>Data tidak ditemukan</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="signature">
        <p>Trayeman, <?php echo formatTanggal(date('Y-m-d')); ?></p>
        <p><strong>Kepala Desa Trayeman</strong></p>
        <br><br><br>
        <p><strong>R. Moh. Sony Noviarso</strong></p>
    </div>
</body>
</html>
