<?php
include 'koneksi.php'; 
if (isset($_GET[penduduk_id])){
	$qry=mysqli_query($konek,"delete from tbl_pindah where kode='".$_GET["penduduk_id"]."'");
	if ($qry){
		header('location: pindah_tampil.php');
	}
}
?>